import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ProductsComponent } from './products/products.component';
import { WhatsnewComponent } from './whatsnew/whatsnew.component';
import { SpecialsComponent } from './specials/specials.component';
import { MyaccountComponent } from './myaccount/myaccount.component';


const routes: Routes = [         
  {path:'',component:HomeComponent},
  {path:'home',component:HomeComponent},
  {path:'whatsnew',component:WhatsnewComponent},
  {path:'specials',component:SpecialsComponent},
  {path:'myaccount',component:MyaccountComponent},
  {path:'products',component:ProductsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
